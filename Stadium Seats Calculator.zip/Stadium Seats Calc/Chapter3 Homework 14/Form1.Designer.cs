﻿namespace Chapter3_Homework_14
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcRevenue = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblStaticSold = new System.Windows.Forms.Label();
            this.lblStaticA = new System.Windows.Forms.Label();
            this.lblStaticB = new System.Windows.Forms.Label();
            this.lblStaticC = new System.Windows.Forms.Label();
            this.lblStaticRev = new System.Windows.Forms.Label();
            this.lblStaticRev2 = new System.Windows.Forms.Label();
            this.lblStaticRev3 = new System.Windows.Forms.Label();
            this.lblStaticTotal = new System.Windows.Forms.Label();
            this.lblRevGeneratedA = new System.Windows.Forms.Label();
            this.grpSold = new System.Windows.Forms.GroupBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.grpRevenue = new System.Windows.Forms.GroupBox();
            this.lblRevGeneratedTotal = new System.Windows.Forms.Label();
            this.lblRevGeneratedC = new System.Windows.Forms.Label();
            this.lblRevGeneratedB = new System.Windows.Forms.Label();
            this.grpSold.SuspendLayout();
            this.grpRevenue.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCalcRevenue
            // 
            this.btnCalcRevenue.Location = new System.Drawing.Point(211, 303);
            this.btnCalcRevenue.Name = "btnCalcRevenue";
            this.btnCalcRevenue.Size = new System.Drawing.Size(95, 44);
            this.btnCalcRevenue.TabIndex = 0;
            this.btnCalcRevenue.Text = "Calculate Revenue";
            this.btnCalcRevenue.UseVisualStyleBackColor = true;
            this.btnCalcRevenue.Click += new System.EventHandler(this.btnCalcRevenue_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(335, 304);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(103, 43);
            this.btnClear.TabIndex = 1;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(466, 304);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(108, 46);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblStaticSold
            // 
            this.lblStaticSold.AutoSize = true;
            this.lblStaticSold.Location = new System.Drawing.Point(24, 27);
            this.lblStaticSold.Name = "lblStaticSold";
            this.lblStaticSold.Size = new System.Drawing.Size(236, 13);
            this.lblStaticSold.TabIndex = 3;
            this.lblStaticSold.Text = "Enter the number of seats sold for each category";
            // 
            // lblStaticA
            // 
            this.lblStaticA.AutoSize = true;
            this.lblStaticA.Location = new System.Drawing.Point(24, 59);
            this.lblStaticA.Name = "lblStaticA";
            this.lblStaticA.Size = new System.Drawing.Size(42, 13);
            this.lblStaticA.TabIndex = 4;
            this.lblStaticA.Text = "Class A";
            // 
            // lblStaticB
            // 
            this.lblStaticB.AutoSize = true;
            this.lblStaticB.Location = new System.Drawing.Point(24, 100);
            this.lblStaticB.Name = "lblStaticB";
            this.lblStaticB.Size = new System.Drawing.Size(42, 13);
            this.lblStaticB.TabIndex = 5;
            this.lblStaticB.Text = "Class B";
            // 
            // lblStaticC
            // 
            this.lblStaticC.AutoSize = true;
            this.lblStaticC.Location = new System.Drawing.Point(24, 143);
            this.lblStaticC.Name = "lblStaticC";
            this.lblStaticC.Size = new System.Drawing.Size(42, 13);
            this.lblStaticC.TabIndex = 6;
            this.lblStaticC.Text = "Class C";
            // 
            // lblStaticRev
            // 
            this.lblStaticRev.AutoSize = true;
            this.lblStaticRev.Location = new System.Drawing.Point(68, 47);
            this.lblStaticRev.Name = "lblStaticRev";
            this.lblStaticRev.Size = new System.Drawing.Size(42, 13);
            this.lblStaticRev.TabIndex = 7;
            this.lblStaticRev.Text = "Class A";
            // 
            // lblStaticRev2
            // 
            this.lblStaticRev2.AutoSize = true;
            this.lblStaticRev2.Location = new System.Drawing.Point(68, 85);
            this.lblStaticRev2.Name = "lblStaticRev2";
            this.lblStaticRev2.Size = new System.Drawing.Size(42, 13);
            this.lblStaticRev2.TabIndex = 8;
            this.lblStaticRev2.Text = "Class B";
            // 
            // lblStaticRev3
            // 
            this.lblStaticRev3.AutoSize = true;
            this.lblStaticRev3.Location = new System.Drawing.Point(68, 117);
            this.lblStaticRev3.Name = "lblStaticRev3";
            this.lblStaticRev3.Size = new System.Drawing.Size(42, 13);
            this.lblStaticRev3.TabIndex = 9;
            this.lblStaticRev3.Text = "Class C";
            // 
            // lblStaticTotal
            // 
            this.lblStaticTotal.AutoSize = true;
            this.lblStaticTotal.Location = new System.Drawing.Point(76, 156);
            this.lblStaticTotal.Name = "lblStaticTotal";
            this.lblStaticTotal.Size = new System.Drawing.Size(34, 13);
            this.lblStaticTotal.TabIndex = 10;
            this.lblStaticTotal.Text = "Total:";
            // 
            // lblRevGeneratedA
            // 
            this.lblRevGeneratedA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRevGeneratedA.Location = new System.Drawing.Point(116, 37);
            this.lblRevGeneratedA.Name = "lblRevGeneratedA";
            this.lblRevGeneratedA.Size = new System.Drawing.Size(131, 23);
            this.lblRevGeneratedA.TabIndex = 11;
            this.lblRevGeneratedA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblRevGeneratedA.Click += new System.EventHandler(this.lblRevGeneratedA_Click);
            // 
            // grpSold
            // 
            this.grpSold.Controls.Add(this.textBox3);
            this.grpSold.Controls.Add(this.textBox2);
            this.grpSold.Controls.Add(this.textBox1);
            this.grpSold.Controls.Add(this.lblStaticC);
            this.grpSold.Controls.Add(this.lblStaticSold);
            this.grpSold.Controls.Add(this.lblStaticA);
            this.grpSold.Controls.Add(this.lblStaticB);
            this.grpSold.Location = new System.Drawing.Point(46, 69);
            this.grpSold.Name = "grpSold";
            this.grpSold.Size = new System.Drawing.Size(283, 187);
            this.grpSold.TabIndex = 12;
            this.grpSold.TabStop = false;
            this.grpSold.Text = "Tickets Sold";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(87, 143);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(144, 20);
            this.textBox3.TabIndex = 9;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(87, 100);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(144, 20);
            this.textBox2.TabIndex = 8;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(87, 59);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(144, 20);
            this.textBox1.TabIndex = 7;
            // 
            // grpRevenue
            // 
            this.grpRevenue.Controls.Add(this.lblRevGeneratedTotal);
            this.grpRevenue.Controls.Add(this.lblRevGeneratedC);
            this.grpRevenue.Controls.Add(this.lblRevGeneratedB);
            this.grpRevenue.Controls.Add(this.lblStaticTotal);
            this.grpRevenue.Controls.Add(this.lblStaticRev);
            this.grpRevenue.Controls.Add(this.lblRevGeneratedA);
            this.grpRevenue.Controls.Add(this.lblStaticRev2);
            this.grpRevenue.Controls.Add(this.lblStaticRev3);
            this.grpRevenue.Location = new System.Drawing.Point(441, 69);
            this.grpRevenue.Name = "grpRevenue";
            this.grpRevenue.Size = new System.Drawing.Size(276, 187);
            this.grpRevenue.TabIndex = 13;
            this.grpRevenue.TabStop = false;
            this.grpRevenue.Text = "Revenue Generated";
            // 
            // lblRevGeneratedTotal
            // 
            this.lblRevGeneratedTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRevGeneratedTotal.Location = new System.Drawing.Point(116, 146);
            this.lblRevGeneratedTotal.Name = "lblRevGeneratedTotal";
            this.lblRevGeneratedTotal.Size = new System.Drawing.Size(131, 23);
            this.lblRevGeneratedTotal.TabIndex = 14;
            this.lblRevGeneratedTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblRevGeneratedTotal.Click += new System.EventHandler(this.lblRevGeneratedTotal_Click);
            // 
            // lblRevGeneratedC
            // 
            this.lblRevGeneratedC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRevGeneratedC.Location = new System.Drawing.Point(116, 107);
            this.lblRevGeneratedC.Name = "lblRevGeneratedC";
            this.lblRevGeneratedC.Size = new System.Drawing.Size(131, 23);
            this.lblRevGeneratedC.TabIndex = 13;
            this.lblRevGeneratedC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblRevGeneratedC.Click += new System.EventHandler(this.lblRevGeneratedC_Click);
            // 
            // lblRevGeneratedB
            // 
            this.lblRevGeneratedB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRevGeneratedB.Location = new System.Drawing.Point(116, 75);
            this.lblRevGeneratedB.Name = "lblRevGeneratedB";
            this.lblRevGeneratedB.Size = new System.Drawing.Size(131, 23);
            this.lblRevGeneratedB.TabIndex = 12;
            this.lblRevGeneratedB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblRevGeneratedB.Click += new System.EventHandler(this.lblRevGeneratedB_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.grpRevenue);
            this.Controls.Add(this.grpSold);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCalcRevenue);
            this.Name = "Form1";
            this.Text = "Stadium Seating";
            this.grpSold.ResumeLayout(false);
            this.grpSold.PerformLayout();
            this.grpRevenue.ResumeLayout(false);
            this.grpRevenue.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCalcRevenue;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblStaticSold;
        private System.Windows.Forms.Label lblStaticA;
        private System.Windows.Forms.Label lblStaticB;
        private System.Windows.Forms.Label lblStaticC;
        private System.Windows.Forms.Label lblStaticRev;
        private System.Windows.Forms.Label lblStaticRev2;
        private System.Windows.Forms.Label lblStaticRev3;
        private System.Windows.Forms.Label lblStaticTotal;
        private System.Windows.Forms.Label lblRevGeneratedA;
        private System.Windows.Forms.GroupBox grpSold;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox grpRevenue;
        private System.Windows.Forms.Label lblRevGeneratedTotal;
        private System.Windows.Forms.Label lblRevGeneratedC;
        private System.Windows.Forms.Label lblRevGeneratedB;
    }
}

