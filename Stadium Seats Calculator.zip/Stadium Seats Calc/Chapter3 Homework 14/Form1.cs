﻿

//
// David Neundorfer
// This program calculates revenue based on customer input of seats bought in different categories
//
//
// Pseudocode:  Import 12 labels, 2 group boxes, 3 buttons, 3 textboxes 
//              Name all
//              Assign proper functions to each button/label/group: calculate, clear, show, exit
//              Create constant variables and assign constant numbers for 3 categories
//              Create variables within the calculate button, parse input, calculate, and show results for each category in each respective label
//              Create an error try/catch statement that displays a message upon incorrect user input and clears the input boxes
//              
//

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter3_Homework_14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //
        // Creates 3 usable constants and assings constant numbers that can be used within the entire scope 
        //

        const double ClassA = 15;
        const double ClassB = 12;
        const double ClassC = 9;


        private void lblRevGeneratedA_Click(object sender, EventArgs e)
        {
            
        }

        private void lblRevGeneratedB_Click(object sender, EventArgs e)
        {

        }

        private void lblRevGeneratedC_Click(object sender, EventArgs e)
        {

        }

        private void lblRevGeneratedTotal_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcRevenue_Click(object sender, EventArgs e)
        {
            //
            // Button that performs main calculation for revenue generated (parses user input, calculates and shows/converts results in labels as currency)
            // in each category with an error loop
            //

            try
            {


                double ClassATotal;
                double ClassBTotal;
                double ClassCTotal;
                double ClassAllTotal;


                ClassATotal = double.Parse(textBox1.Text) * ClassA;
                ClassBTotal = double.Parse(textBox2.Text) * ClassB;
                ClassCTotal = double.Parse(textBox3.Text) * ClassC;
                ClassAllTotal = ClassATotal + ClassBTotal + ClassCTotal;


                lblRevGeneratedA.Text = ClassATotal.ToString("c");
                lblRevGeneratedB.Text = ClassBTotal.ToString("c");
                lblRevGeneratedC.Text = ClassCTotal.ToString("c");
                lblRevGeneratedTotal.Text = ClassAllTotal.ToString("c");

            }
            catch
            {
                MessageBox.Show("Please enter valid integers in each prompted category! If a categories number of sold tickets is zero please enter the number 0.");
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //
            // Clear button that performs clear function in all fields
            //

            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";


            lblRevGeneratedA.Text = "";
            lblRevGeneratedB.Text = "";
            lblRevGeneratedC.Text = "";
            lblRevGeneratedTotal.Text = "";


        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //
            // Assigns exit function to exit button
            //

            this.Close();
        }
    }
}
